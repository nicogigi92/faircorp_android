package com.faircorp

interface OnWindowSelectedListener {
    fun onWindowSelected(id: Long)
}